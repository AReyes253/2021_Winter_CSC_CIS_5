/* 
 * File:   main.cpp
 * Author: Angel Reyes
 * Created on January 10
 * Purpose: Personal Information
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants

//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process

    //Display Inputs/Outputs
    cout << "Angel Reyes\n2717 hall ave\nRiverside, CA 92509\n626-486-5991\nComputer Science";
    //Exit the Program - Cleanup
    return 0;
}