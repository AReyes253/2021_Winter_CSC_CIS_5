/* 
 * File:   main.cpp
 * Author: Angel Reyes
 * Created on January 5
 * Purpose: Diamond Pattern 
 */

//System Libraries
#include <iostream>  //I/O Library
using namespace std;

//User Libraries

//Global Constants

//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout << "   *   " << endl;
    cout << "  ***  " << endl;
    cout << " ***** " << endl;
    cout << "*******" << endl;
    cout << " ***** " << endl;
    cout << "  ***  " << endl;
    cout << "   *   " << endl;
    //Exit the Program - Cleanup
    return 0;
}